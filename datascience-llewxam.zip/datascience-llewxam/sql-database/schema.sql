-- Data Science Platform Database Schema
-- Made By Llewxam

-- =====================================================
-- E-COMMERCE TABLES
-- =====================================================

-- Customers table
CREATE TABLE customers (
    customer_id VARCHAR(20) PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    state VARCHAR(2) NOT NULL,
    city VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL CHECK (price > 0),
    cost DECIMAL(10,2) NOT NULL CHECK (cost > 0),
    stock_quantity INTEGER NOT NULL DEFAULT 0,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Transactions table
CREATE TABLE transactions (
    transaction_id VARCHAR(20) PRIMARY KEY,
    customer_id VARCHAR(20) NOT NULL,
    product_id INTEGER NOT NULL,
    transaction_date TIMESTAMP NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price > 0),
    discount DECIMAL(5,3) DEFAULT 0 CHECK (discount >= 0 AND discount <= 1),
    total_amount DECIMAL(12,2) NOT NULL CHECK (total_amount >= 0),
    channel VARCHAR(50) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Pending',
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- =====================================================
-- FINANCIAL TABLES
-- =====================================================

-- Stock symbols table
CREATE TABLE stock_symbols (
    symbol VARCHAR(10) PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    sector VARCHAR(100),
    market_cap BIGINT,
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Stock prices table (OHLCV data)
CREATE TABLE stock_prices (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    price_date DATE NOT NULL,
    open_price DECIMAL(12,4) NOT NULL,
    high_price DECIMAL(12,4) NOT NULL,
    low_price DECIMAL(12,4) NOT NULL,
    close_price DECIMAL(12,4) NOT NULL,
    volume BIGINT NOT NULL,
    adjusted_close DECIMAL(12,4),
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (symbol) REFERENCES stock_symbols(symbol),
    UNIQUE(symbol, price_date)
);

-- Portfolio holdings
CREATE TABLE portfolio_holdings (
    id SERIAL PRIMARY KEY,
    symbol VARCHAR(10) NOT NULL,
    shares DECIMAL(12,4) NOT NULL,
    avg_cost DECIMAL(12,4) NOT NULL,
    purchase_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (symbol) REFERENCES stock_symbols(symbol)
);

-- =====================================================
-- IOT SENSOR TABLES
-- =====================================================

-- Sensor types
CREATE TABLE sensor_types (
    type_id SERIAL PRIMARY KEY,
    type_name VARCHAR(50) UNIQUE NOT NULL,
    unit VARCHAR(20) NOT NULL,
    min_value DECIMAL(10,4),
    max_value DECIMAL(10,4),
    description TEXT,
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Locations
CREATE TABLE locations (
    location_id SERIAL PRIMARY KEY,
    location_name VARCHAR(100) UNIQUE NOT NULL,
    building VARCHAR(100),
    floor INTEGER,
    room VARCHAR(50),
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sensors
CREATE TABLE sensors (
    sensor_id VARCHAR(50) PRIMARY KEY,
    type_id INTEGER NOT NULL,
    location_id INTEGER NOT NULL,
    model VARCHAR(100),
    installation_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (type_id) REFERENCES sensor_types(type_id),
    FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

-- Sensor readings (partitioned by date for performance)
CREATE TABLE sensor_readings (
    id BIGSERIAL,
    sensor_id VARCHAR(50) NOT NULL,
    reading_timestamp TIMESTAMP NOT NULL,
    value DECIMAL(12,4) NOT NULL,
    status VARCHAR(20) DEFAULT 'online',
    battery_level INTEGER CHECK (battery_level >= 0 AND battery_level <= 100),
    signal_strength INTEGER CHECK (signal_strength >= -100 AND signal_strength <= 0),
    created_by VARCHAR(50) DEFAULT 'Llewxam',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (sensor_id) REFERENCES sensors(sensor_id),
    PRIMARY KEY (id, reading_timestamp)
) PARTITION BY RANGE (reading_timestamp);

-- Create monthly partitions for sensor readings
CREATE TABLE sensor_readings_2023_01 PARTITION OF sensor_readings
    FOR VALUES FROM ('2023-01-01') TO ('2023-02-01');

CREATE TABLE sensor_readings_2023_02 PARTITION OF sensor_readings
    FOR VALUES FROM ('2023-02-01') TO ('2023-03-01');

CREATE TABLE sensor_readings_2023_03 PARTITION OF sensor_readings
    FOR VALUES FROM ('2023-03-01') TO ('2023-04-01');

CREATE TABLE sensor_readings_2023_04 PARTITION OF sensor_readings
    FOR VALUES FROM ('2023-04-01') TO ('2023-05-01');

CREATE TABLE sensor_readings_2023_05 PARTITION OF sensor_readings
    FOR VALUES FROM ('2023-05-01') TO ('2023-06-01');

CREATE TABLE sensor_readings_2023_06 PARTITION OF sensor_readings
    FOR VALUES FROM ('2023-06-01') TO ('2023-07-01');

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- E-commerce indexes
CREATE INDEX idx_transactions_date ON transactions(transaction_date);
CREATE INDEX idx_transactions_customer ON transactions(customer_id);
CREATE INDEX idx_transactions_product ON transactions(product_id);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_customers_state ON customers(state);
CREATE INDEX idx_products_category ON products(category);

-- Financial indexes
CREATE INDEX idx_stock_prices_symbol_date ON stock_prices(symbol, price_date);
CREATE INDEX idx_stock_prices_date ON stock_prices(price_date);
CREATE INDEX idx_portfolio_symbol ON portfolio_holdings(symbol);

-- IoT indexes
CREATE INDEX idx_sensor_readings_sensor_time ON sensor_readings(sensor_id, reading_timestamp);
CREATE INDEX idx_sensor_readings_timestamp ON sensor_readings(reading_timestamp);
CREATE INDEX idx_sensors_type ON sensors(type_id);
CREATE INDEX idx_sensors_location ON sensors(location_id);

-- =====================================================
-- VIEWS FOR ANALYTICS
-- =====================================================

-- Daily sales summary
CREATE VIEW daily_sales_summary AS
SELECT 
    DATE(transaction_date) as sale_date,
    COUNT(*) as total_orders,
    SUM(total_amount) as total_revenue,
    AVG(total_amount) as avg_order_value,
    COUNT(DISTINCT customer_id) as unique_customers
FROM transactions 
WHERE status = 'Delivered'
GROUP BY DATE(transaction_date)
ORDER BY sale_date;

-- Category performance
CREATE VIEW category_performance AS
SELECT 
    p.category,
    COUNT(t.transaction_id) as total_orders,
    SUM(t.total_amount) as total_revenue,
    AVG(t.total_amount) as avg_order_value,
    SUM(t.quantity) as total_quantity
FROM transactions t
JOIN products p ON t.product_id = p.product_id
WHERE t.status = 'Delivered'
GROUP BY p.category
ORDER BY total_revenue DESC;

-- Stock performance view
CREATE VIEW stock_performance AS
SELECT 
    sp.symbol,
    ss.company_name,
    sp.close_price as current_price,
    LAG(sp.close_price, 1) OVER (PARTITION BY sp.symbol ORDER BY sp.price_date) as prev_price,
    ((sp.close_price - LAG(sp.close_price, 1) OVER (PARTITION BY sp.symbol ORDER BY sp.price_date)) / 
     LAG(sp.close_price, 1) OVER (PARTITION BY sp.symbol ORDER BY sp.price_date)) * 100 as daily_change_pct,
    sp.volume,
    sp.price_date
FROM stock_prices sp
JOIN stock_symbols ss ON sp.symbol = ss.symbol
ORDER BY sp.symbol, sp.price_date;

-- Sensor status summary
CREATE VIEW sensor_status_summary AS
SELECT 
    st.type_name,
    l.location_name,
    s.sensor_id,
    sr.status,
    sr.value as last_reading,
    sr.reading_timestamp as last_update,
    st.unit
FROM sensors s
JOIN sensor_types st ON s.type_id = st.type_id
JOIN locations l ON s.location_id = l.location_id
LEFT JOIN LATERAL (
    SELECT status, value, reading_timestamp
    FROM sensor_readings sr2
    WHERE sr2.sensor_id = s.sensor_id
    ORDER BY reading_timestamp DESC
    LIMIT 1
) sr ON true
WHERE s.is_active = true;

-- =====================================================
-- FUNCTIONS AND PROCEDURES
-- =====================================================

-- Function to calculate customer lifetime value
CREATE OR REPLACE FUNCTION calculate_customer_ltv(p_customer_id VARCHAR(20))
RETURNS DECIMAL(12,2) AS $$
DECLARE
    ltv DECIMAL(12,2);
BEGIN
    SELECT COALESCE(SUM(total_amount), 0)
    INTO ltv
    FROM transactions
    WHERE customer_id = p_customer_id
    AND status = 'Delivered';
    
    RETURN ltv;
END;
$$ LANGUAGE plpgsql;

-- Function to get stock volatility
CREATE OR REPLACE FUNCTION calculate_stock_volatility(
    p_symbol VARCHAR(10),
    p_days INTEGER DEFAULT 30
)
RETURNS DECIMAL(8,4) AS $$
DECLARE
    volatility DECIMAL(8,4);
BEGIN
    WITH daily_returns AS (
        SELECT 
            (close_price - LAG(close_price) OVER (ORDER BY price_date)) / 
            LAG(close_price) OVER (ORDER BY price_date) as daily_return
        FROM stock_prices
        WHERE symbol = p_symbol
        AND price_date >= CURRENT_DATE - INTERVAL '1 day' * p_days
        ORDER BY price_date
    )
    SELECT STDDEV(daily_return) * SQRT(252) -- Annualized volatility
    INTO volatility
    FROM daily_returns
    WHERE daily_return IS NOT NULL;
    
    RETURN COALESCE(volatility, 0);
END;
$$ LANGUAGE plpgsql;

-- Procedure to update sensor status based on last reading
CREATE OR REPLACE PROCEDURE update_sensor_status()
LANGUAGE plpgsql AS $$
BEGIN
    -- Mark sensors as offline if no reading in last 30 minutes
    UPDATE sensors 
    SET is_active = false
    WHERE sensor_id IN (
        SELECT s.sensor_id
        FROM sensors s
        LEFT JOIN sensor_readings sr ON s.sensor_id = sr.sensor_id
        GROUP BY s.sensor_id
        HAVING MAX(sr.reading_timestamp) < NOW() - INTERVAL '30 minutes'
        OR MAX(sr.reading_timestamp) IS NULL
    );
    
    -- Mark sensors as active if recent reading
    UPDATE sensors 
    SET is_active = true
    WHERE sensor_id IN (
        SELECT s.sensor_id
        FROM sensors s
        JOIN sensor_readings sr ON s.sensor_id = sr.sensor_id
        WHERE sr.reading_timestamp >= NOW() - INTERVAL '30 minutes'
    );
END;
$$;

-- =====================================================
-- TRIGGERS
-- =====================================================

-- Update timestamp trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply update triggers to relevant tables
CREATE TRIGGER update_customers_updated_at 
    BEFORE UPDATE ON customers 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_products_updated_at 
    BEFORE UPDATE ON products 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- SAMPLE DATA INSERTION
-- =====================================================

-- Insert sensor types
INSERT INTO sensor_types (type_name, unit, min_value, max_value, description) VALUES
('Temperature', '°C', -40, 85, 'Temperature sensor'),
('Humidity', '%', 0, 100, 'Humidity sensor'),
('Pressure', 'hPa', 800, 1200, 'Atmospheric pressure sensor'),
('Light', 'lux', 0, 100000, 'Light intensity sensor'),
('Motion', 'boolean', 0, 1, 'Motion detection sensor');

-- Insert locations
INSERT INTO locations (location_name, building, floor, room) VALUES
('Building_A', 'Main Building', 1, 'Room 101'),
('Building_B', 'Main Building', 2, 'Room 201'),
('Building_C', 'Annex Building', 1, 'Room 301'),
('Warehouse', 'Storage Building', 1, 'Storage Area'),
('Factory', 'Production Building', 1, 'Production Floor');

-- Insert stock symbols
INSERT INTO stock_symbols (symbol, company_name, sector, market_cap) VALUES
('AAPL', 'Apple Inc.', 'Technology', 3000000000000),
('GOOGL', 'Alphabet Inc.', 'Technology', 1800000000000),
('MSFT', 'Microsoft Corporation', 'Technology', 2800000000000),
('AMZN', 'Amazon.com Inc.', 'Consumer Discretionary', 1500000000000),
('TSLA', 'Tesla Inc.', 'Consumer Discretionary', 800000000000),
('META', 'Meta Platforms Inc.', 'Technology', 900000000000),
('NVDA', 'NVIDIA Corporation', 'Technology', 1200000000000),
('NFLX', 'Netflix Inc.', 'Communication Services', 200000000000);

-- =====================================================
-- COMMENTS
-- =====================================================

COMMENT ON DATABASE postgres IS 'Data Science Platform Database - Made By Llewxam';
COMMENT ON TABLE customers IS 'Customer information for e-commerce analytics';
COMMENT ON TABLE transactions IS 'E-commerce transaction data';
COMMENT ON TABLE stock_prices IS 'Historical stock price data (OHLCV)';
COMMENT ON TABLE sensor_readings IS 'IoT sensor readings (partitioned by date)';
COMMENT ON VIEW daily_sales_summary IS 'Daily aggregated sales metrics';
COMMENT ON FUNCTION calculate_customer_ltv IS 'Calculate customer lifetime value';

-- Made By Llewxam - Data Science Platform
-- Schema version: 1.0
-- Last updated: 2024

