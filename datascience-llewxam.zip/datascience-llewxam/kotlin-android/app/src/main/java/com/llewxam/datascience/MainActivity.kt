package com.llewxam.datascience

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.llewxam.datascience.ui.theme.DataScienceTheme
import dagger.hilt.android.AndroidEntryPoint

// Made By Llewxam - Data Science Android App

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DataScienceTheme {
                DataScienceApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataScienceApp() {
    val navController = rememberNavController()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Column {
                        Text(
                            text = "Data Science Platform",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Made By Llewxam",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        },
        bottomBar = {
            BottomNavigationBar(navController)
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.padding(paddingValues)
        ) {
            composable("dashboard") { DashboardScreen() }
            composable("analytics") { AnalyticsScreen() }
            composable("sensors") { SensorsScreen() }
            composable("profile") { ProfileScreen() }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    var selectedItem by remember { mutableIntStateOf(0) }
    val items = listOf(
        BottomNavItem("Dashboard", Icons.Filled.Dashboard, "dashboard"),
        BottomNavItem("Analytics", Icons.Filled.Analytics, "analytics"),
        BottomNavItem("Sensors", Icons.Filled.Sensors, "sensors"),
        BottomNavItem("Profile", Icons.Filled.Person, "profile")
    )

    NavigationBar {
        items.forEachIndexed { index, item ->
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                selected = selectedItem == index,
                onClick = {
                    selectedItem = index
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.startDestinationId)
                        launchSingleTop = true
                    }
                }
            )
        }
    }
}

data class BottomNavItem(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val route: String
)

@Composable
fun DashboardScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "📊 Dashboard Overview",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        // KPI Cards
        items(getKPIData()) { kpi ->
            KPICard(kpi = kpi)
        }
        
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "🎯 Llewxam passou por aqui!",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun AnalyticsScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "📈 Analytics",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        items(getAnalyticsData()) { analytics ->
            AnalyticsCard(analytics = analytics)
        }
    }
}

@Composable
fun SensorsScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "🌡️ IoT Sensors",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }
        
        items(getSensorData()) { sensor ->
            SensorCard(sensor = sensor)
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.Person,
            contentDescription = "Profile",
            modifier = Modifier.size(120.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Llewxam",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = "Data Science Developer",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "🚀 About This App",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Data Science Platform mobile app desenvolvido em Kotlin com Jetpack Compose. " +
                            "Demonstra expertise em desenvolvimento Android moderno, arquitetura MVVM, " +
                            "e integração com APIs de dados.",
                    style = MaterialTheme.typography.bodyMedium
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "🎯 Made By Llewxam",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KPICard(kpi: KPIData) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = kpi.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = kpi.value,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = kpi.change,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (kpi.isPositive) Color.Green else Color.Red
                )
            }
            
            Icon(
                imageVector = kpi.icon,
                contentDescription = kpi.title,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsCard(analytics: AnalyticsData) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = analytics.category,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                
                Badge {
                    Text(text = analytics.trend)
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Revenue: ${analytics.revenue}",
                style = MaterialTheme.typography.bodyMedium
            )
            
            Text(
                text = "Orders: ${analytics.orders}",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SensorCard(sensor: SensorData) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = sensor.type,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = sensor.location,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${sensor.value} ${sensor.unit}",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            
            Column(
                horizontalAlignment = Alignment.End
            ) {
                Badge(
                    containerColor = if (sensor.isOnline) Color.Green else Color.Red
                ) {
                    Text(
                        text = if (sensor.isOnline) "Online" else "Offline",
                        color = Color.White
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = sensor.lastUpdate,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// Data Classes
data class KPIData(
    val title: String,
    val value: String,
    val change: String,
    val isPositive: Boolean,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

data class AnalyticsData(
    val category: String,
    val revenue: String,
    val orders: String,
    val trend: String
)

data class SensorData(
    val type: String,
    val location: String,
    val value: String,
    val unit: String,
    val isOnline: Boolean,
    val lastUpdate: String
)

// Sample Data Functions
fun getKPIData(): List<KPIData> {
    return listOf(
        KPIData("Total Revenue", "R$ 8.8M", "+12.5%", true, Icons.Filled.AttachMoney),
        KPIData("Total Orders", "6,250", "+8.2%", true, Icons.Filled.ShoppingCart),
        KPIData("Active Sensors", "125", "97.9% uptime", true, Icons.Filled.Sensors),
        KPIData("Portfolio Value", "R$ 1.25M", "-2.1%", false, Icons.Filled.TrendingUp)
    )
}

fun getAnalyticsData(): List<AnalyticsData> {
    return listOf(
        AnalyticsData("Electronics", "R$ 2.5M", "1,200", "+15.2%"),
        AnalyticsData("Clothing", "R$ 1.8M", "2,100", "+8.7%"),
        AnalyticsData("Home & Garden", "R$ 1.2M", "800", "+12.3%"),
        AnalyticsData("Sports", "R$ 900K", "650", "-2.1%"),
        AnalyticsData("Books", "R$ 400K", "1,500", "+5.8%")
    )
}

fun getSensorData(): List<SensorData> {
    return listOf(
        SensorData("Temperature", "Building A", "20.07", "°C", true, "2 min ago"),
        SensorData("Humidity", "Building B", "60.00", "%", true, "1 min ago"),
        SensorData("Pressure", "Warehouse", "1013.12", "hPa", true, "3 min ago"),
        SensorData("Light", "Factory", "333.82", "lux", false, "15 min ago"),
        SensorData("Motion", "Building C", "0.38", "boolean", true, "30 sec ago")
    )
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    DataScienceTheme {
        DataScienceApp()
    }
}

