import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  AreaChart, Area, ScatterChart, Scatter
} from 'recharts'
import { 
  TrendingUp, TrendingDown, ShoppingCart, DollarSign, 
  Activity, Users, BarChart3, PieChart as PieChartIcon,
  Database, Wifi, WifiOff, Thermometer, Droplets
} from 'lucide-react'
import './App.css'

// Made By Llewxam - Data Science Dashboard

function App() {
  const [activeTab, setActiveTab] = useState('overview')
  const [darkMode, setDarkMode] = useState(false)

  // Dados simulados baseados nos datasets gerados
  const ecommerceData = [
    { category: 'Electronics', sales: 2500000, orders: 1200, growth: 15.2 },
    { category: 'Clothing', sales: 1800000, orders: 2100, growth: 8.7 },
    { category: 'Home & Garden', sales: 1200000, orders: 800, growth: 12.3 },
    { category: 'Sports', sales: 900000, orders: 650, growth: -2.1 },
    { category: 'Books', sales: 400000, orders: 1500, growth: 5.8 }
  ]

  const financialData = [
    { symbol: 'AAPL', price: 207.85, change: 38.63, volume: 1200000 },
    { symbol: 'GOOGL', price: 112.31, change: 12.31, volume: 980000 },
    { symbol: 'MSFT', price: 246.00, change: -1.62, volume: 1100000 },
    { symbol: 'AMZN', price: 207.91, change: 131.01, volume: 1500000 },
    { symbol: 'TSLA', price: 91.02, change: -54.49, volume: 2100000 }
  ]

  const monthlyTrend = [
    { month: 'Jan', sales: 1200000, orders: 2400 },
    { month: 'Feb', sales: 1350000, orders: 2600 },
    { month: 'Mar', sales: 1180000, orders: 2200 },
    { month: 'Apr', sales: 1420000, orders: 2800 },
    { month: 'May', sales: 1680000, orders: 3200 },
    { month: 'Jun', sales: 1850000, orders: 3600 }
  ]

  const iotSensors = [
    { type: 'Temperature', value: 20.07, unit: '°C', status: 'online', location: 'Building A' },
    { type: 'Humidity', value: 60.00, unit: '%', status: 'online', location: 'Building B' },
    { type: 'Pressure', value: 1013.12, unit: 'hPa', status: 'online', location: 'Warehouse' },
    { type: 'Light', value: 333.82, unit: 'lux', status: 'offline', location: 'Factory' },
    { type: 'Motion', value: 0.38, unit: 'boolean', status: 'online', location: 'Building C' }
  ]

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8']

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
    document.documentElement.classList.toggle('dark')
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value)
  }

  const formatNumber = (value) => {
    return new Intl.NumberFormat('pt-BR').format(value)
  }

  return (
    <div className={`min-h-screen bg-background text-foreground ${darkMode ? 'dark' : ''}`}>
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Database className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">Data Science Platform</h1>
                <p className="text-sm text-muted-foreground">Made By Llewxam</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-xs">
                Live Data
              </Badge>
              <Button 
                variant="outline" 
                size="sm"
                onClick={toggleDarkMode}
              >
                {darkMode ? '☀️' : '🌙'}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="ecommerce">E-commerce</TabsTrigger>
            <TabsTrigger value="financial">Financial</TabsTrigger>
            <TabsTrigger value="iot">IoT Sensors</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(8800000)}</div>
                  <p className="text-xs text-muted-foreground">
                    <TrendingUp className="inline h-3 w-3 mr-1" />
                    +12.5% from last month
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatNumber(6250)}</div>
                  <p className="text-xs text-muted-foreground">
                    <TrendingUp className="inline h-3 w-3 mr-1" />
                    +8.2% from last month
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Sensors</CardTitle>
                  <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">125</div>
                  <p className="text-xs text-muted-foreground">
                    <Wifi className="inline h-3 w-3 mr-1" />
                    97.9% uptime
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Portfolio Value</CardTitle>
                  <BarChart3 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatCurrency(1250000)}</div>
                  <p className="text-xs text-muted-foreground">
                    <TrendingDown className="inline h-3 w-3 mr-1" />
                    -2.1% from last week
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Sales Trend</CardTitle>
                  <CardDescription>Revenue and orders over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={monthlyTrend}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value, name) => [
                        name === 'sales' ? formatCurrency(value) : formatNumber(value),
                        name === 'sales' ? 'Sales' : 'Orders'
                      ]} />
                      <Area type="monotone" dataKey="sales" stackId="1" stroke="#8884d8" fill="#8884d8" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Sales by Category</CardTitle>
                  <CardDescription>Revenue distribution</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={ecommerceData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ category, percent }) => `${category} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="sales"
                      >
                        {ecommerceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => formatCurrency(value)} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* E-commerce Tab */}
          <TabsContent value="ecommerce" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Category Performance</CardTitle>
                  <CardDescription>Sales and growth by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={ecommerceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="category" />
                      <YAxis />
                      <Tooltip formatter={(value, name) => [
                        name === 'sales' ? formatCurrency(value) : formatNumber(value),
                        name === 'sales' ? 'Sales' : 'Orders'
                      ]} />
                      <Legend />
                      <Bar dataKey="sales" fill="#8884d8" name="Sales" />
                      <Bar dataKey="orders" fill="#82ca9d" name="Orders" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Growth Analysis</CardTitle>
                  <CardDescription>Category growth rates</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {ecommerceData.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{item.category}</p>
                        <p className="text-sm text-muted-foreground">
                          {formatCurrency(item.sales)} • {formatNumber(item.orders)} orders
                        </p>
                      </div>
                      <Badge variant={item.growth > 0 ? "default" : "destructive"}>
                        {item.growth > 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                        {item.growth > 0 ? '+' : ''}{item.growth}%
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Financial Tab */}
          <TabsContent value="financial" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Stock Performance</CardTitle>
                  <CardDescription>YTD performance by symbol</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={400}>
                    <BarChart data={financialData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="symbol" />
                      <YAxis />
                      <Tooltip formatter={(value, name) => [
                        name === 'change' ? `${value}%` : formatCurrency(value),
                        name === 'change' ? 'Change' : name === 'price' ? 'Price' : 'Volume'
                      ]} />
                      <Bar dataKey="change" fill="#8884d8" name="YTD Change %" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Portfolio Overview</CardTitle>
                  <CardDescription>Current positions and performance</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {financialData.map((stock, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{stock.symbol}</p>
                        <p className="text-sm text-muted-foreground">
                          {formatCurrency(stock.price)} • Vol: {formatNumber(stock.volume)}
                        </p>
                      </div>
                      <Badge variant={stock.change > 0 ? "default" : "destructive"}>
                        {stock.change > 0 ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                        {stock.change > 0 ? '+' : ''}{stock.change}%
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* IoT Tab */}
          <TabsContent value="iot" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Sensor Status</CardTitle>
                  <CardDescription>Real-time sensor monitoring</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {iotSensors.map((sensor, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        {sensor.type === 'Temperature' && <Thermometer className="h-5 w-5 text-orange-500" />}
                        {sensor.type === 'Humidity' && <Droplets className="h-5 w-5 text-blue-500" />}
                        {sensor.type === 'Pressure' && <Activity className="h-5 w-5 text-purple-500" />}
                        {sensor.type === 'Light' && <Activity className="h-5 w-5 text-yellow-500" />}
                        {sensor.type === 'Motion' && <Activity className="h-5 w-5 text-green-500" />}
                        <div>
                          <p className="font-medium">{sensor.type}</p>
                          <p className="text-sm text-muted-foreground">{sensor.location}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{sensor.value} {sensor.unit}</p>
                        <div className="flex items-center space-x-1">
                          {sensor.status === 'online' ? 
                            <Wifi className="h-3 w-3 text-green-500" /> : 
                            <WifiOff className="h-3 w-3 text-red-500" />
                          }
                          <span className={`text-xs ${sensor.status === 'online' ? 'text-green-500' : 'text-red-500'}`}>
                            {sensor.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Sensor Distribution</CardTitle>
                  <CardDescription>Sensors by type and status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-green-500">122</div>
                      <p className="text-sm text-muted-foreground">Online</p>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-red-500">3</div>
                      <p className="text-sm text-muted-foreground">Offline</p>
                    </div>
                  </div>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'Online', value: 122, fill: '#10b981' },
                          { name: 'Offline', value: 3, fill: '#ef4444' }
                        ]}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              © 2024 Data Science Platform - Made By Llewxam
            </p>
            <div className="flex items-center space-x-4">
              <Badge variant="outline">
                🎯 Llewxam passou por aqui!
              </Badge>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

