#!/usr/bin/env python3
"""
ETL Pipeline - Made By Llewxam
Pipeline completo de Extract, Transform, Load para Data Science Platform
"""

import pandas as pd
import numpy as np
import psycopg2
from datetime import datetime, timedelta
import logging
import json
import os
from typing import Dict, List, Any
import time

# Made By Llewxam - ETL Pipeline

class ETLProcessor:
    def __init__(self, config_file='config.json'):
        """Inicializa o processador ETL"""
        self.config = self._load_config(config_file)
        self.setup_logging()
        self.db_connection = None
        
    def _load_config(self, config_file):
        """Carrega configurações do ETL"""
        default_config = {
            "database": {
                "host": "localhost",
                "port": 5432,
                "database": "datascience_db",
                "user": "postgres",
                "password": "password"
            },
            "data_sources": {
                "ecommerce": "../datasets/ecommerce_data.csv",
                "financial": "../datasets/financial_data.csv",
                "iot": "../datasets/iot_sensors_data.csv"
            },
            "batch_size": 1000,
            "retry_attempts": 3,
            "retry_delay": 5
        }
        
        if os.path.exists(config_file):
            with open(config_file, 'r') as f:
                user_config = json.load(f)
                default_config.update(user_config)
        
        return default_config
    
    def setup_logging(self):
        """Configura logging do ETL"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('etl_pipeline.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info("🚀 ETL Pipeline iniciado - Made By Llewxam")
    
    def connect_database(self):
        """Conecta ao banco de dados PostgreSQL"""
        try:
            db_config = self.config['database']
            self.db_connection = psycopg2.connect(
                host=db_config['host'],
                port=db_config['port'],
                database=db_config['database'],
                user=db_config['user'],
                password=db_config['password']
            )
            self.logger.info("✅ Conectado ao banco de dados")
            return True
        except Exception as e:
            self.logger.error(f"❌ Erro ao conectar ao banco: {e}")
            return False
    
    def extract_data(self, source_type: str) -> pd.DataFrame:
        """Extrai dados de diferentes fontes"""
        self.logger.info(f"📥 Extraindo dados: {source_type}")
        
        try:
            source_path = self.config['data_sources'][source_type]
            
            if source_path.endswith('.csv'):
                df = pd.read_csv(source_path)
            elif source_path.endswith('.json'):
                df = pd.read_json(source_path)
            else:
                raise ValueError(f"Formato não suportado: {source_path}")
            
            self.logger.info(f"✅ Extraídos {len(df)} registros de {source_type}")
            return df
            
        except Exception as e:
            self.logger.error(f"❌ Erro na extração de {source_type}: {e}")
            raise
    
    def transform_ecommerce_data(self, df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """Transforma dados de e-commerce"""
        self.logger.info("🔄 Transformando dados de e-commerce")
        
        # Converter datas
        df['transaction_date'] = pd.to_datetime(df['transaction_date'])
        
        # Criar tabela de clientes únicos
        customers = df[['customer_id']].drop_duplicates()
        customers['first_name'] = customers['customer_id'].apply(lambda x: f"Customer_{x.split('_')[1]}")
        customers['last_name'] = "Silva"
        customers['email'] = customers['customer_id'].apply(lambda x: f"customer_{x.split('_')[1]}@email.com")
        customers['phone'] = customers['customer_id'].apply(lambda x: f"(11) 9{x.split('_')[1][:4]}-{x.split('_')[1][4:]}")
        customers['registration_date'] = datetime.now() - timedelta(days=np.random.randint(30, 365))
        customers['state'] = df.groupby('customer_id')['state'].first().values
        customers['city'] = customers['state'].apply(lambda x: f"Cidade_{x}")
        customers['created_by'] = 'Llewxam'
        
        # Criar tabela de produtos únicos
        products = df[['product', 'category', 'price']].drop_duplicates()
        products = products.rename(columns={'product': 'product_name'})
        products['cost'] = products['price'] * 0.6  # Margem de 40%
        products['stock_quantity'] = np.random.randint(10, 1000, len(products))
        products['description'] = products['product_name'].apply(lambda x: f"Descrição do produto {x}")
        products['created_by'] = 'Llewxam'
        products.reset_index(drop=True, inplace=True)
        products['product_id'] = products.index + 1
        
        # Mapear product_id nas transações
        product_map = dict(zip(products['product_name'], products['product_id']))
        df['product_id'] = df['product'].map(product_map)
        
        # Preparar tabela de transações
        transactions = df[[
            'transaction_id', 'customer_id', 'product_id', 'transaction_date',
            'quantity', 'price', 'discount', 'total_amount', 'channel',
            'payment_method', 'status', 'created_by'
        ]].copy()
        transactions = transactions.rename(columns={'price': 'unit_price'})
        
        self.logger.info(f"✅ Transformação concluída: {len(customers)} clientes, {len(products)} produtos, {len(transactions)} transações")
        
        return {
            'customers': customers,
            'products': products,
            'transactions': transactions
        }
    
    def transform_financial_data(self, df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """Transforma dados financeiros"""
        self.logger.info("🔄 Transformando dados financeiros")
        
        # Converter datas
        df['date'] = pd.to_datetime(df['date'])
        
        # Preparar dados de preços
        stock_prices = df[[
            'symbol', 'date', 'open', 'high', 'low', 'close', 'volume', 'created_by'
        ]].copy()
        stock_prices = stock_prices.rename(columns={
            'date': 'price_date',
            'open': 'open_price',
            'high': 'high_price',
            'low': 'low_price',
            'close': 'close_price'
        })
        stock_prices['adjusted_close'] = stock_prices['close_price']
        
        # Criar holdings de portfólio simulados
        symbols = df['symbol'].unique()
        portfolio_holdings = []
        
        for symbol in symbols:
            shares = np.random.uniform(10, 100)
            avg_cost = df[df['symbol'] == symbol]['close_price'].mean() * np.random.uniform(0.8, 1.2)
            purchase_date = datetime.now() - timedelta(days=np.random.randint(30, 365))
            
            portfolio_holdings.append({
                'symbol': symbol,
                'shares': round(shares, 4),
                'avg_cost': round(avg_cost, 4),
                'purchase_date': purchase_date,
                'created_by': 'Llewxam'
            })
        
        portfolio_df = pd.DataFrame(portfolio_holdings)
        
        self.logger.info(f"✅ Transformação concluída: {len(stock_prices)} preços, {len(portfolio_df)} holdings")
        
        return {
            'stock_prices': stock_prices,
            'portfolio_holdings': portfolio_df
        }
    
    def transform_iot_data(self, df: pd.DataFrame) -> Dict[str, pd.DataFrame]:
        """Transforma dados de IoT"""
        self.logger.info("🔄 Transformando dados de IoT")
        
        # Converter timestamps
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Criar mapeamento de tipos de sensor
        type_map = {
            'Temperature': 1, 'Humidity': 2, 'Pressure': 3, 
            'Light': 4, 'Motion': 5
        }
        
        # Criar mapeamento de localizações
        location_map = {
            'Building_A': 1, 'Building_B': 2, 'Building_C': 3,
            'Warehouse': 4, 'Factory': 5
        }
        
        # Preparar tabela de sensores únicos
        sensors = df[['sensor_id', 'sensor_type', 'location']].drop_duplicates()
        sensors['type_id'] = sensors['sensor_type'].map(type_map)
        sensors['location_id'] = sensors['location'].map(location_map)
        sensors['model'] = sensors['sensor_type'].apply(lambda x: f"Model_{x}_v2.1")
        sensors['installation_date'] = datetime.now() - timedelta(days=np.random.randint(30, 180))
        sensors['created_by'] = 'Llewxam'
        sensors = sensors[['sensor_id', 'type_id', 'location_id', 'model', 'installation_date', 'created_by']]
        
        # Preparar leituras dos sensores
        sensor_readings = df[[
            'sensor_id', 'timestamp', 'value', 'status', 'created_by'
        ]].copy()
        sensor_readings = sensor_readings.rename(columns={'timestamp': 'reading_timestamp'})
        sensor_readings['battery_level'] = np.random.randint(20, 100, len(sensor_readings))
        sensor_readings['signal_strength'] = np.random.randint(-80, -20, len(sensor_readings))
        
        self.logger.info(f"✅ Transformação concluída: {len(sensors)} sensores, {len(sensor_readings)} leituras")
        
        return {
            'sensors': sensors,
            'sensor_readings': sensor_readings
        }
    
    def load_data(self, table_name: str, df: pd.DataFrame, batch_size: int = None):
        """Carrega dados no banco de dados"""
        if batch_size is None:
            batch_size = self.config['batch_size']
        
        self.logger.info(f"📤 Carregando {len(df)} registros na tabela {table_name}")
        
        try:
            cursor = self.db_connection.cursor()
            
            # Preparar query de inserção
            columns = ', '.join(df.columns)
            placeholders = ', '.join(['%s'] * len(df.columns))
            query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
            
            # Inserir em lotes
            total_inserted = 0
            for i in range(0, len(df), batch_size):
                batch = df.iloc[i:i+batch_size]
                values = [tuple(row) for row in batch.values]
                
                cursor.executemany(query, values)
                total_inserted += len(batch)
                
                if total_inserted % (batch_size * 5) == 0:
                    self.logger.info(f"  Inseridos {total_inserted}/{len(df)} registros...")
            
            self.db_connection.commit()
            self.logger.info(f"✅ Carregamento concluído: {total_inserted} registros em {table_name}")
            
        except Exception as e:
            self.db_connection.rollback()
            self.logger.error(f"❌ Erro no carregamento de {table_name}: {e}")
            raise
        finally:
            cursor.close()
    
    def run_data_quality_checks(self):
        """Executa verificações de qualidade dos dados"""
        self.logger.info("🔍 Executando verificações de qualidade")
        
        quality_checks = [
            ("Transações sem cliente", "SELECT COUNT(*) FROM transactions WHERE customer_id NOT IN (SELECT customer_id FROM customers)"),
            ("Preços negativos", "SELECT COUNT(*) FROM transactions WHERE unit_price < 0"),
            ("Sensores sem leituras", "SELECT COUNT(*) FROM sensors WHERE sensor_id NOT IN (SELECT DISTINCT sensor_id FROM sensor_readings)"),
            ("Leituras futuras", "SELECT COUNT(*) FROM sensor_readings WHERE reading_timestamp > NOW()"),
        ]
        
        cursor = self.db_connection.cursor()
        
        for check_name, query in quality_checks:
            cursor.execute(query)
            result = cursor.fetchone()[0]
            
            if result > 0:
                self.logger.warning(f"⚠️ {check_name}: {result} registros")
            else:
                self.logger.info(f"✅ {check_name}: OK")
        
        cursor.close()
    
    def generate_summary_report(self):
        """Gera relatório resumo do ETL"""
        self.logger.info("📊 Gerando relatório resumo")
        
        summary_queries = {
            "Total de clientes": "SELECT COUNT(*) FROM customers",
            "Total de produtos": "SELECT COUNT(*) FROM products", 
            "Total de transações": "SELECT COUNT(*) FROM transactions",
            "Receita total": "SELECT SUM(total_amount) FROM transactions WHERE status = 'Delivered'",
            "Símbolos de ações": "SELECT COUNT(*) FROM stock_symbols",
            "Preços históricos": "SELECT COUNT(*) FROM stock_prices",
            "Sensores ativos": "SELECT COUNT(*) FROM sensors WHERE is_active = true",
            "Leituras de sensores": "SELECT COUNT(*) FROM sensor_readings"
        }
        
        cursor = self.db_connection.cursor()
        report = {}
        
        for metric, query in summary_queries.items():
            cursor.execute(query)
            result = cursor.fetchone()[0]
            report[metric] = result
            self.logger.info(f"  {metric}: {result:,}")
        
        cursor.close()
        
        # Salvar relatório
        report['timestamp'] = datetime.now().isoformat()
        report['processed_by'] = 'Llewxam'
        
        with open('etl_summary_report.json', 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        self.logger.info("📄 Relatório salvo em: etl_summary_report.json")
        return report
    
    def run_full_pipeline(self):
        """Executa pipeline ETL completo"""
        start_time = time.time()
        self.logger.info("🚀 Iniciando pipeline ETL completo - Made By Llewxam")
        
        try:
            # Conectar ao banco
            if not self.connect_database():
                raise Exception("Falha na conexão com banco de dados")
            
            # Processar dados de e-commerce
            ecommerce_df = self.extract_data('ecommerce')
            ecommerce_tables = self.transform_ecommerce_data(ecommerce_df)
            
            self.load_data('customers', ecommerce_tables['customers'])
            self.load_data('products', ecommerce_tables['products'])
            self.load_data('transactions', ecommerce_tables['transactions'])
            
            # Processar dados financeiros
            financial_df = self.extract_data('financial')
            financial_tables = self.transform_financial_data(financial_df)
            
            self.load_data('stock_prices', financial_tables['stock_prices'])
            self.load_data('portfolio_holdings', financial_tables['portfolio_holdings'])
            
            # Processar dados de IoT
            iot_df = self.extract_data('iot')
            iot_tables = self.transform_iot_data(iot_df)
            
            self.load_data('sensors', iot_tables['sensors'])
            self.load_data('sensor_readings', iot_tables['sensor_readings'])
            
            # Verificações de qualidade
            self.run_data_quality_checks()
            
            # Relatório final
            report = self.generate_summary_report()
            
            elapsed_time = time.time() - start_time
            self.logger.info(f"🎉 Pipeline ETL concluído em {elapsed_time:.2f} segundos")
            self.logger.info("🎯 Llewxam passou por aqui!")
            
            return report
            
        except Exception as e:
            self.logger.error(f"❌ Falha no pipeline ETL: {e}")
            raise
        finally:
            if self.db_connection:
                self.db_connection.close()
                self.logger.info("🔌 Conexão com banco fechada")

def main():
    """Função principal"""
    etl = ETLProcessor()
    
    try:
        report = etl.run_full_pipeline()
        print("\n" + "="*60)
        print("📊 RELATÓRIO FINAL DO ETL - Made By Llewxam")
        print("="*60)
        
        for metric, value in report.items():
            if metric not in ['timestamp', 'processed_by']:
                print(f"{metric}: {value:,}")
        
        print(f"\nProcessado por: {report['processed_by']}")
        print(f"Timestamp: {report['timestamp']}")
        print("\n🎯 Llewxam passou por aqui!")
        
    except Exception as e:
        print(f"❌ Erro na execução: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())

