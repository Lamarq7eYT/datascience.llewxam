#!/usr/bin/env python3
"""
Data Generator - Made By Llewxam
Gerador de dados sintéticos realistas para análise
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
from faker import Faker
import json

# Made By Llewxam - Data Science Platform

class DataGenerator:
    def __init__(self, seed=42):
        """Inicializa gerador com seed para reprodutibilidade"""
        np.random.seed(seed)
        random.seed(seed)
        self.fake = Faker()
        Faker.seed(seed)
        
    def generate_ecommerce_data(self, num_records=10000):
        """Gera dados de e-commerce realistas"""
        print("🛒 Gerando dados de e-commerce - Made By Llewxam")
        
        # Categorias de produtos
        categories = [
            'Electronics', 'Clothing', 'Home & Garden', 'Sports', 
            'Books', 'Beauty', 'Automotive', 'Toys', 'Health'
        ]
        
        # Produtos por categoria
        products = {
            'Electronics': ['Smartphone', 'Laptop', 'Tablet', 'Headphones', 'Camera'],
            'Clothing': ['T-Shirt', 'Jeans', 'Dress', 'Shoes', 'Jacket'],
            'Home & Garden': ['Sofa', 'Table', 'Lamp', 'Plant', 'Curtains'],
            'Sports': ['Running Shoes', 'Yoga Mat', 'Dumbbell', 'Bicycle', 'Tennis Racket'],
            'Books': ['Fiction Novel', 'Technical Book', 'Biography', 'Cookbook', 'Travel Guide'],
            'Beauty': ['Lipstick', 'Foundation', 'Perfume', 'Skincare', 'Nail Polish'],
            'Automotive': ['Car Parts', 'Oil', 'Tires', 'GPS', 'Car Accessories'],
            'Toys': ['Action Figure', 'Board Game', 'Puzzle', 'Doll', 'Building Blocks'],
            'Health': ['Vitamins', 'Protein Powder', 'First Aid', 'Thermometer', 'Supplements']
        }
        
        data = []
        start_date = datetime(2023, 1, 1)
        
        for i in range(num_records):
            # Data da transação (com sazonalidade)
            days_offset = np.random.exponential(30) % 365
            transaction_date = start_date + timedelta(days=days_offset)
            
            # Sazonalidade (mais vendas no final do ano)
            seasonal_factor = 1.0
            if transaction_date.month in [11, 12]:  # Black Friday, Natal
                seasonal_factor = 1.5
            elif transaction_date.month in [6, 7]:  # Férias de verão
                seasonal_factor = 1.2
            
            # Categoria e produto
            category = np.random.choice(categories, p=[0.2, 0.15, 0.12, 0.1, 0.08, 0.08, 0.07, 0.07, 0.13])
            product = np.random.choice(products[category])
            
            # Preço baseado na categoria
            base_prices = {
                'Electronics': (50, 2000), 'Clothing': (20, 200), 'Home & Garden': (30, 500),
                'Sports': (25, 300), 'Books': (10, 50), 'Beauty': (15, 100),
                'Automotive': (20, 500), 'Toys': (10, 100), 'Health': (15, 80)
            }
            
            min_price, max_price = base_prices[category]
            price = np.random.uniform(min_price, max_price) * seasonal_factor
            
            # Quantidade (produtos mais caros tendem a ter menor quantidade)
            if price > 500:
                quantity = np.random.choice([1, 2], p=[0.8, 0.2])
            elif price > 100:
                quantity = np.random.choice([1, 2, 3], p=[0.6, 0.3, 0.1])
            else:
                quantity = np.random.choice([1, 2, 3, 4, 5], p=[0.4, 0.3, 0.15, 0.1, 0.05])
            
            # Cliente
            customer_id = f"CUST_{i % 2000:04d}"  # 2000 clientes únicos
            
            # Localização (com distribuição realista)
            states = ['SP', 'RJ', 'MG', 'RS', 'PR', 'SC', 'BA', 'GO', 'PE', 'CE']
            state_weights = [0.25, 0.15, 0.12, 0.08, 0.08, 0.06, 0.06, 0.05, 0.05, 0.1]
            state = np.random.choice(states, p=state_weights)
            
            # Canal de venda
            channel = np.random.choice(['Online', 'Mobile App', 'Physical Store'], p=[0.5, 0.3, 0.2])
            
            # Método de pagamento
            payment_method = np.random.choice(['Credit Card', 'Debit Card', 'PIX', 'Boleto'], p=[0.4, 0.25, 0.25, 0.1])
            
            # Status do pedido
            status_weights = [0.85, 0.1, 0.03, 0.02]  # Delivered, Shipped, Cancelled, Returned
            status = np.random.choice(['Delivered', 'Shipped', 'Cancelled', 'Returned'], p=status_weights)
            
            # Desconto (ocasional)
            discount = 0
            if np.random.random() < 0.15:  # 15% chance de desconto
                discount = np.random.uniform(0.05, 0.3)  # 5% a 30%
            
            total_amount = price * quantity * (1 - discount)
            
            data.append({
                'transaction_id': f"TXN_{i:06d}",
                'customer_id': customer_id,
                'transaction_date': transaction_date,
                'category': category,
                'product': product,
                'price': round(price, 2),
                'quantity': quantity,
                'discount': round(discount, 3),
                'total_amount': round(total_amount, 2),
                'state': state,
                'channel': channel,
                'payment_method': payment_method,
                'status': status,
                'created_by': 'Llewxam'
            })
        
        df = pd.DataFrame(data)
        print(f"✅ Gerados {len(df)} registros de e-commerce")
        return df
    
    def generate_financial_data(self, num_days=365):
        """Gera dados financeiros de mercado"""
        print("💰 Gerando dados financeiros - Made By Llewxam")
        
        # Símbolos de ações
        symbols = ['AAPL', 'GOOGL', 'MSFT', 'AMZN', 'TSLA', 'META', 'NVDA', 'NFLX']
        
        data = []
        start_date = datetime(2023, 1, 1)
        
        for symbol in symbols:
            # Preço inicial baseado no símbolo
            base_prices = {
                'AAPL': 150, 'GOOGL': 100, 'MSFT': 250, 'AMZN': 90,
                'TSLA': 200, 'META': 120, 'NVDA': 400, 'NFLX': 350
            }
            
            current_price = base_prices[symbol]
            
            for day in range(num_days):
                date = start_date + timedelta(days=day)
                
                # Skip weekends
                if date.weekday() >= 5:
                    continue
                
                # Volatilidade baseada no símbolo
                volatilities = {
                    'AAPL': 0.02, 'GOOGL': 0.025, 'MSFT': 0.02, 'AMZN': 0.03,
                    'TSLA': 0.05, 'META': 0.035, 'NVDA': 0.04, 'NFLX': 0.03
                }
                
                volatility = volatilities[symbol]
                
                # Movimento do preço (random walk com drift)
                drift = 0.0002  # Tendência ligeiramente positiva
                change = np.random.normal(drift, volatility)
                current_price *= (1 + change)
                
                # Preço de abertura (com gap pequeno)
                open_price = current_price * (1 + np.random.normal(0, 0.005))
                
                # High e Low baseados na volatilidade do dia
                daily_volatility = abs(np.random.normal(0, volatility))
                high_price = max(open_price, current_price) * (1 + daily_volatility)
                low_price = min(open_price, current_price) * (1 - daily_volatility)
                
                # Volume (com padrões realistas)
                base_volume = 1000000
                volume_multiplier = np.random.lognormal(0, 0.5)
                volume = int(base_volume * volume_multiplier)
                
                data.append({
                    'symbol': symbol,
                    'date': date,
                    'open': round(open_price, 2),
                    'high': round(high_price, 2),
                    'low': round(low_price, 2),
                    'close': round(current_price, 2),
                    'volume': volume,
                    'created_by': 'Llewxam'
                })
        
        df = pd.DataFrame(data)
        print(f"✅ Gerados {len(df)} registros financeiros")
        return df
    
    def generate_iot_sensor_data(self, num_records=50000):
        """Gera dados de sensores IoT"""
        print("🌡️ Gerando dados de sensores IoT - Made By Llewxam")
        
        # Tipos de sensores
        sensor_types = ['Temperature', 'Humidity', 'Pressure', 'Light', 'Motion']
        locations = ['Building_A', 'Building_B', 'Building_C', 'Warehouse', 'Factory']
        
        data = []
        start_time = datetime(2023, 1, 1)
        
        for i in range(num_records):
            # Timestamp com intervalos regulares + ruído
            base_interval = timedelta(minutes=5)  # Leitura a cada 5 minutos
            noise = timedelta(seconds=np.random.randint(-30, 31))
            timestamp = start_time + (base_interval * i) + noise
            
            sensor_type = np.random.choice(sensor_types)
            location = np.random.choice(locations)
            sensor_id = f"{sensor_type}_{location}_{np.random.randint(1, 6):02d}"
            
            # Valores baseados no tipo de sensor e padrões temporais
            hour = timestamp.hour
            
            if sensor_type == 'Temperature':
                # Padrão diário de temperatura
                base_temp = 20 + 5 * np.sin(2 * np.pi * (hour - 6) / 24)
                value = base_temp + np.random.normal(0, 2)
                unit = '°C'
            elif sensor_type == 'Humidity':
                # Umidade inversamente relacionada à temperatura
                base_humidity = 60 - 2 * np.sin(2 * np.pi * (hour - 6) / 24)
                value = max(0, min(100, base_humidity + np.random.normal(0, 5)))
                unit = '%'
            elif sensor_type == 'Pressure':
                # Pressão atmosférica com variação pequena
                value = 1013.25 + np.random.normal(0, 5)
                unit = 'hPa'
            elif sensor_type == 'Light':
                # Luz baseada no horário (dia/noite)
                if 6 <= hour <= 18:
                    value = np.random.uniform(200, 1000)
                else:
                    value = np.random.uniform(0, 50)
                unit = 'lux'
            else:  # Motion
                # Sensor de movimento (binário com probabilidade baseada no horário)
                if 8 <= hour <= 18:  # Horário comercial
                    value = np.random.choice([0, 1], p=[0.3, 0.7])
                else:
                    value = np.random.choice([0, 1], p=[0.9, 0.1])
                unit = 'boolean'
            
            # Status do sensor (ocasionalmente offline)
            status = 'online' if np.random.random() > 0.02 else 'offline'
            
            data.append({
                'sensor_id': sensor_id,
                'sensor_type': sensor_type,
                'location': location,
                'timestamp': timestamp,
                'value': round(value, 2) if sensor_type != 'Motion' else int(value),
                'unit': unit,
                'status': status,
                'created_by': 'Llewxam'
            })
        
        df = pd.DataFrame(data)
        print(f"✅ Gerados {len(df)} registros de sensores IoT")
        return df
    
    def save_datasets(self, output_dir='../datasets'):
        """Gera e salva todos os datasets"""
        print("💾 Salvando datasets - Made By Llewxam")
        
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Gerar datasets
        ecommerce_df = self.generate_ecommerce_data(10000)
        financial_df = self.generate_financial_data(365)
        iot_df = self.generate_iot_sensor_data(50000)
        
        # Salvar em diferentes formatos
        datasets = {
            'ecommerce': ecommerce_df,
            'financial': financial_df,
            'iot_sensors': iot_df
        }
        
        for name, df in datasets.items():
            # CSV
            csv_path = f"{output_dir}/{name}_data.csv"
            df.to_csv(csv_path, index=False)
            print(f"📄 Salvo: {csv_path}")
            
            # JSON
            json_path = f"{output_dir}/{name}_data.json"
            df.to_json(json_path, orient='records', date_format='iso')
            print(f"📄 Salvo: {json_path}")
            
            # Parquet (formato otimizado)
            try:
                parquet_path = f"{output_dir}/{name}_data.parquet"
                df.to_parquet(parquet_path, index=False)
                print(f"📄 Salvo: {parquet_path}")
            except ImportError:
                print("⚠️ PyArrow não disponível, pulando formato Parquet")
        
        # Salvar metadados
        metadata = {
            'generated_by': 'Llewxam',
            'generation_date': datetime.now().isoformat(),
            'datasets': {
                'ecommerce': {
                    'records': len(ecommerce_df),
                    'columns': list(ecommerce_df.columns),
                    'description': 'E-commerce transaction data with realistic patterns'
                },
                'financial': {
                    'records': len(financial_df),
                    'columns': list(financial_df.columns),
                    'description': 'Stock market data with OHLCV format'
                },
                'iot_sensors': {
                    'records': len(iot_df),
                    'columns': list(iot_df.columns),
                    'description': 'IoT sensor readings with temporal patterns'
                }
            }
        }
        
        metadata_path = f"{output_dir}/metadata.json"
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        print(f"📄 Salvo: {metadata_path}")
        
        print(f"\n🎉 Todos os datasets salvos em: {output_dir}")
        print("Llewxam passou por aqui! 🎯")

if __name__ == "__main__":
    generator = DataGenerator()
    generator.save_datasets()

