#!/usr/bin/env python3
"""
Exploratory Data Analysis (EDA) - Made By Llewxam
Análise exploratória automatizada de dados
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Made By Llewxam - Data Science Platform

class EDAAnalyzer:
    def __init__(self, figsize=(12, 8)):
        """Inicializa analisador EDA"""
        self.figsize = figsize
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")
        
    def analyze_dataset(self, df, dataset_name="Dataset"):
        """Análise completa de um dataset"""
        print(f"📊 Análise EDA: {dataset_name} - Made By Llewxam")
        print("=" * 60)
        
        # Informações básicas
        self._basic_info(df, dataset_name)
        
        # Análise de valores ausentes
        self._missing_values_analysis(df)
        
        # Análise de tipos de dados
        self._data_types_analysis(df)
        
        # Estatísticas descritivas
        self._descriptive_statistics(df)
        
        # Análise de correlação
        self._correlation_analysis(df)
        
        # Análise de distribuições
        self._distribution_analysis(df)
        
        # Detecção de outliers
        self._outlier_detection(df)
        
        print(f"\n🎯 Análise EDA concluída - Llewxam passou por aqui!")
        
    def _basic_info(self, df, dataset_name):
        """Informações básicas do dataset"""
        print(f"\n📋 Informações Básicas - {dataset_name}")
        print("-" * 40)
        print(f"Dimensões: {df.shape[0]:,} linhas × {df.shape[1]} colunas")
        print(f"Tamanho em memória: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
        print(f"Período dos dados: {self._get_date_range(df)}")
        
        print(f"\nColunas ({len(df.columns)}):")
        for i, col in enumerate(df.columns, 1):
            print(f"  {i:2d}. {col} ({df[col].dtype})")
    
    def _get_date_range(self, df):
        """Identifica range de datas no dataset"""
        date_columns = df.select_dtypes(include=['datetime64']).columns
        if len(date_columns) > 0:
            date_col = date_columns[0]
            min_date = df[date_col].min()
            max_date = df[date_col].max()
            return f"{min_date.strftime('%Y-%m-%d')} a {max_date.strftime('%Y-%m-%d')}"
        return "Não identificado"
    
    def _missing_values_analysis(self, df):
        """Análise de valores ausentes"""
        print(f"\n🔍 Análise de Valores Ausentes")
        print("-" * 40)
        
        missing = df.isnull().sum()
        missing_pct = (missing / len(df)) * 100
        
        missing_df = pd.DataFrame({
            'Coluna': missing.index,
            'Valores Ausentes': missing.values,
            'Percentual (%)': missing_pct.values
        }).sort_values('Valores Ausentes', ascending=False)
        
        if missing_df['Valores Ausentes'].sum() == 0:
            print("✅ Nenhum valor ausente encontrado!")
        else:
            print("⚠️ Valores ausentes encontrados:")
            for _, row in missing_df[missing_df['Valores Ausentes'] > 0].iterrows():
                print(f"  {row['Coluna']}: {row['Valores Ausentes']:,} ({row['Percentual (%)']:.2f}%)")
    
    def _data_types_analysis(self, df):
        """Análise de tipos de dados"""
        print(f"\n🏷️ Análise de Tipos de Dados")
        print("-" * 40)
        
        type_counts = df.dtypes.value_counts()
        for dtype, count in type_counts.items():
            print(f"  {dtype}: {count} colunas")
        
        # Identificar colunas categóricas
        categorical_cols = df.select_dtypes(include=['object']).columns
        if len(categorical_cols) > 0:
            print(f"\n📝 Colunas Categóricas ({len(categorical_cols)}):")
            for col in categorical_cols:
                unique_count = df[col].nunique()
                print(f"  {col}: {unique_count} valores únicos")
    
    def _descriptive_statistics(self, df):
        """Estatísticas descritivas"""
        print(f"\n📈 Estatísticas Descritivas")
        print("-" * 40)
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            stats = df[numeric_cols].describe()
            print(stats.round(2))
        else:
            print("Nenhuma coluna numérica encontrada.")
    
    def _correlation_analysis(self, df):
        """Análise de correlação"""
        print(f"\n🔗 Análise de Correlação")
        print("-" * 40)
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) < 2:
            print("Insuficientes colunas numéricas para análise de correlação.")
            return
        
        corr_matrix = df[numeric_cols].corr()
        
        # Encontrar correlações mais fortes
        corr_pairs = []
        for i in range(len(corr_matrix.columns)):
            for j in range(i+1, len(corr_matrix.columns)):
                col1 = corr_matrix.columns[i]
                col2 = corr_matrix.columns[j]
                corr_value = corr_matrix.iloc[i, j]
                corr_pairs.append((col1, col2, corr_value))
        
        # Ordenar por correlação absoluta
        corr_pairs.sort(key=lambda x: abs(x[2]), reverse=True)
        
        print("Correlações mais fortes:")
        for col1, col2, corr in corr_pairs[:5]:
            print(f"  {col1} ↔ {col2}: {corr:.3f}")
        
        # Plotar heatmap de correlação
        plt.figure(figsize=self.figsize)
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, 
                   square=True, fmt='.2f')
        plt.title('Matriz de Correlação - Made By Llewxam')
        plt.tight_layout()
        plt.savefig('../docs/correlation_heatmap.png', dpi=300, bbox_inches='tight')
        plt.close()
        print("📊 Heatmap de correlação salvo em: ../docs/correlation_heatmap.png")
    
    def _distribution_analysis(self, df):
        """Análise de distribuições"""
        print(f"\n📊 Análise de Distribuições")
        print("-" * 40)
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        if len(numeric_cols) == 0:
            print("Nenhuma coluna numérica para análise de distribuição.")
            return
        
        # Plotar distribuições
        n_cols = min(4, len(numeric_cols))
        n_rows = (len(numeric_cols) + n_cols - 1) // n_cols
        
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols*4, n_rows*3))
        if n_rows == 1:
            axes = [axes] if n_cols == 1 else axes
        else:
            axes = axes.flatten()
        
        for i, col in enumerate(numeric_cols):
            if i < len(axes):
                # Histograma com KDE
                sns.histplot(df[col].dropna(), kde=True, ax=axes[i])
                axes[i].set_title(f'Distribuição: {col}')
                axes[i].grid(True, alpha=0.3)
        
        # Remover subplots vazios
        for i in range(len(numeric_cols), len(axes)):
            fig.delaxes(axes[i])
        
        plt.suptitle('Distribuições das Variáveis Numéricas - Made By Llewxam', 
                    fontsize=16, y=1.02)
        plt.tight_layout()
        plt.savefig('../docs/distributions.png', dpi=300, bbox_inches='tight')
        plt.close()
        print("📊 Gráficos de distribuição salvos em: ../docs/distributions.png")
        
        # Análise de normalidade
        print("\nTeste de Normalidade (Shapiro-Wilk):")
        from scipy import stats
        for col in numeric_cols[:5]:  # Limitar a 5 colunas
            sample = df[col].dropna().sample(min(5000, len(df[col].dropna())))
            if len(sample) > 3:
                stat, p_value = stats.shapiro(sample)
                normal = "✅ Normal" if p_value > 0.05 else "❌ Não normal"
                print(f"  {col}: {normal} (p={p_value:.4f})")
    
    def _outlier_detection(self, df):
        """Detecção de outliers"""
        print(f"\n🎯 Detecção de Outliers")
        print("-" * 40)
        
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        
        if len(numeric_cols) == 0:
            print("Nenhuma coluna numérica para detecção de outliers.")
            return
        
        outlier_summary = []
        
        for col in numeric_cols:
            data = df[col].dropna()
            
            # Método IQR
            Q1 = data.quantile(0.25)
            Q3 = data.quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            outliers_iqr = data[(data < lower_bound) | (data > upper_bound)]
            outlier_pct = (len(outliers_iqr) / len(data)) * 100
            
            outlier_summary.append({
                'Coluna': col,
                'Outliers': len(outliers_iqr),
                'Percentual (%)': outlier_pct,
                'Limite Inferior': lower_bound,
                'Limite Superior': upper_bound
            })
        
        outlier_df = pd.DataFrame(outlier_summary)
        outlier_df = outlier_df.sort_values('Percentual (%)', ascending=False)
        
        print("Outliers detectados (método IQR):")
        for _, row in outlier_df.iterrows():
            if row['Outliers'] > 0:
                print(f"  {row['Coluna']}: {row['Outliers']:,} ({row['Percentual (%)']:.2f}%)")
        
        # Boxplots para visualizar outliers
        if len(numeric_cols) > 0:
            n_cols = min(4, len(numeric_cols))
            n_rows = (len(numeric_cols) + n_cols - 1) // n_cols
            
            fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols*4, n_rows*3))
            if n_rows == 1:
                axes = [axes] if n_cols == 1 else axes
            else:
                axes = axes.flatten()
            
            for i, col in enumerate(numeric_cols):
                if i < len(axes):
                    sns.boxplot(y=df[col], ax=axes[i])
                    axes[i].set_title(f'Boxplot: {col}')
                    axes[i].grid(True, alpha=0.3)
            
            # Remover subplots vazios
            for i in range(len(numeric_cols), len(axes)):
                fig.delaxes(axes[i])
            
            plt.suptitle('Boxplots para Detecção de Outliers - Made By Llewxam', 
                        fontsize=16, y=1.02)
            plt.tight_layout()
            plt.savefig('../docs/outliers_boxplots.png', dpi=300, bbox_inches='tight')
            plt.close()
            print("📊 Boxplots salvos em: ../docs/outliers_boxplots.png")

def analyze_ecommerce_data():
    """Análise específica dos dados de e-commerce"""
    print("🛒 Análise Específica: E-commerce - Made By Llewxam")
    
    df = pd.read_csv('../datasets/ecommerce_data.csv')
    df['transaction_date'] = pd.to_datetime(df['transaction_date'])
    
    analyzer = EDAAnalyzer()
    analyzer.analyze_dataset(df, "E-commerce Dataset")
    
    # Análises específicas de e-commerce
    print(f"\n🎯 Insights Específicos de E-commerce")
    print("-" * 40)
    
    # Top categorias
    print("Top 5 Categorias por Vendas:")
    category_sales = df.groupby('category')['total_amount'].sum().sort_values(ascending=False)
    for cat, sales in category_sales.head().items():
        print(f"  {cat}: R$ {sales:,.2f}")
    
    # Análise temporal
    monthly_sales = df.groupby(df['transaction_date'].dt.to_period('M'))['total_amount'].sum()
    print(f"\nVendas por Mês:")
    for month, sales in monthly_sales.items():
        print(f"  {month}: R$ {sales:,.2f}")
    
    # Top estados
    print(f"\nTop 5 Estados por Volume:")
    state_volume = df['state'].value_counts()
    for state, count in state_volume.head().items():
        print(f"  {state}: {count:,} transações")

def analyze_financial_data():
    """Análise específica dos dados financeiros"""
    print("💰 Análise Específica: Financeiro - Made By Llewxam")
    
    df = pd.read_csv('../datasets/financial_data.csv')
    df['date'] = pd.to_datetime(df['date'])
    
    analyzer = EDAAnalyzer()
    analyzer.analyze_dataset(df, "Financial Dataset")
    
    # Análises específicas financeiras
    print(f"\n🎯 Insights Específicos Financeiros")
    print("-" * 40)
    
    # Performance por símbolo
    print("Performance YTD por Símbolo:")
    for symbol in df['symbol'].unique():
        symbol_data = df[df['symbol'] == symbol].sort_values('date')
        if len(symbol_data) > 1:
            start_price = symbol_data.iloc[0]['close']
            end_price = symbol_data.iloc[-1]['close']
            performance = ((end_price - start_price) / start_price) * 100
            print(f"  {symbol}: {performance:+.2f}%")
    
    # Volatilidade
    print(f"\nVolatilidade (desvio padrão dos retornos):")
    for symbol in df['symbol'].unique():
        symbol_data = df[df['symbol'] == symbol].sort_values('date')
        if len(symbol_data) > 1:
            returns = symbol_data['close'].pct_change().dropna()
            volatility = returns.std() * np.sqrt(252) * 100  # Anualizada
            print(f"  {symbol}: {volatility:.2f}%")

def analyze_iot_data():
    """Análise específica dos dados de IoT"""
    print("🌡️ Análise Específica: IoT Sensores - Made By Llewxam")
    
    df = pd.read_csv('../datasets/iot_sensors_data.csv')
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    
    analyzer = EDAAnalyzer()
    analyzer.analyze_dataset(df, "IoT Sensors Dataset")
    
    # Análises específicas de IoT
    print(f"\n🎯 Insights Específicos de IoT")
    print("-" * 40)
    
    # Status dos sensores
    print("Status dos Sensores:")
    status_counts = df['status'].value_counts()
    for status, count in status_counts.items():
        pct = (count / len(df)) * 100
        print(f"  {status}: {count:,} ({pct:.2f}%)")
    
    # Sensores por tipo
    print(f"\nSensores por Tipo:")
    type_counts = df['sensor_type'].value_counts()
    for sensor_type, count in type_counts.items():
        print(f"  {sensor_type}: {count:,} leituras")
    
    # Média por tipo de sensor
    print(f"\nValores Médios por Tipo:")
    avg_values = df.groupby('sensor_type')['value'].mean()
    for sensor_type, avg_val in avg_values.items():
        unit = df[df['sensor_type'] == sensor_type]['unit'].iloc[0]
        print(f"  {sensor_type}: {avg_val:.2f} {unit}")

if __name__ == "__main__":
    # Criar diretório para salvar gráficos
    import os
    os.makedirs('../docs', exist_ok=True)
    
    # Executar análises
    analyze_ecommerce_data()
    print("\n" + "="*80 + "\n")
    
    analyze_financial_data()
    print("\n" + "="*80 + "\n")
    
    analyze_iot_data()
    
    print(f"\n🎉 Todas as análises EDA concluídas!")
    print("Llewxam passou por aqui! 🎯")

